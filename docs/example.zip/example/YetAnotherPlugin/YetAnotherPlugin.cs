﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using plugin;

namespace YetAnotherPlugin
{
    public class YetAnotherPlugin : MarshalByRefObject, IPlugin
    {
        public void Init() { }
        public String Name() { return "YetAnotherPlugin"; }
        public String Version() { return "1.0.2"; }
    }
}
