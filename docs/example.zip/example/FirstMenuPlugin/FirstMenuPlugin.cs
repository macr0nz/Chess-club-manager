﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using plugin;


namespace FirstMenuPlugin
{
    public class FirstMenuPlugin : MarshalByRefObject, MenuPlugin, IPlugin
    {
        public void Init() { }
        public String Name() { return "FirstMenuPlugin"; }
        public String Version() { return "1.0.0"; }
        public void Menu(List<String> menu)
        {
            menu.Add("<a href='#'>First Menu</a>");
        }
    }
}
