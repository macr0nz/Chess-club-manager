﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using plugin;
using System.Reflection;

namespace example
{
    public class PluginLoader
    {
        public static List<IPlugin> plugins = new List<IPlugin>();
        public static String pluginDirectory = HttpRuntime.AppDomainAppPath + Path.DirectorySeparatorChar + "Plugins";
        private static AppDomain domain = AppDomain.CurrentDomain;

        private static List<IPlugin> EnumeratePlugins()
        {
            IEnumerable<string> fileNames = Directory.EnumerateFiles(pluginDirectory, "*.dll");
            List<IPlugin> result = new List<IPlugin>();

            if (fileNames != null)
            {
                foreach (string assemblyFileName in fileNames)
                {
                    System.Diagnostics.Debug.WriteLine(">>> filenames: " + assemblyFileName);
                    foreach (string typeName in GetTypes(assemblyFileName, typeof(IPlugin)))
                    {
                        System.Runtime.Remoting.ObjectHandle handle;
                        try
                        {
                            handle = domain.CreateInstanceFrom(assemblyFileName, typeName);
                        }
                        catch (MissingMethodException ex)
                        {
                            System.Diagnostics.Debug.WriteLine(">>> missing exception: " + ex.ToString());
                            continue;
                        }
                        object obj = handle.Unwrap();
                        if (obj.GetType().Equals(typeof(IPlugin)) == false) {
                            result.Add((IPlugin)obj);
                        }
                        
                    }
                }
            }
            return result;
        }

        private static List<string> GetTypes(string assemblyFileName, Type interfaceFilter)
        {
            List<string> result = new List<string>();
            try
            {
                Assembly asm = domain.Load(AssemblyName.GetAssemblyName(assemblyFileName));
                Type[] types = asm.GetTypes();
                foreach (Type type in types)
                {
                    if (type.GetInterface(interfaceFilter.Name) != null)
                    {
                        result.Add(type.FullName);
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(">>> exception: " + e.ToString());
                System.Diagnostics.Debug.WriteLine(">>> assembly filename: " + assemblyFileName);
            }
            return result;
        }

        public static void UnloadPlugins()
        {
            AppDomain.Unload(domain);
        }

        public static void LoadPlugins()
        {
            plugins = EnumeratePlugins();
        }
    }
}