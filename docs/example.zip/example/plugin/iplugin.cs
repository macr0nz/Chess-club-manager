﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plugin
{
    public interface IPlugin
    {
        void Init();
        String Name();
        String Version();
    }

    public interface MenuPlugin
    {
        void Menu(List<String> menu);
    }

    public interface FooterPlugin
    {
        String Footer(String footer);
    }
}
